CREATE OR REPLACE VIEW DEMO_DB.BRONZE.cdm_subscription AS
SELECT 
    customer,
    product,
    LAST_DAY(start_date) AS monthenddate,
    annual_value
FROM DEMO_DB.BRONZE.subscriptions;
