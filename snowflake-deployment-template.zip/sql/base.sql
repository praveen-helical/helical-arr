EXECUTE IMMEDIATE FROM './01_warehouses/create_warehouses.sql';
EXECUTE IMMEDIATE FROM './02_databases/create_database.sql';
EXECUTE IMMEDIATE FROM './03_schemas/create_schemas.sql';
EXECUTE IMMEDIATE FROM './04_tables/customers.sql';
EXECUTE IMMEDIATE FROM './04_tables/subscriptions.sql';
EXECUTE IMMEDIATE FROM './05_views/cdm_subscription.sql';
EXECUTE IMMEDIATE FROM './06_grants/grants.sql';
