CREATE OR REPLACE TABLE DEMO_DB.BRONZE.subscriptions (
    customer STRING,
    product STRING,
    start_date DATE,
    end_date DATE,
    annual_value NUMBER
);

INSERT INTO DEMO_DB.BRONZE.subscriptions VALUES
('Ravi Kumar', 'Product A', '2024-01-01', '2024-12-31', 1000),
('Anita Sharma', 'Product B', '2024-03-01', '2024-09-30', 2000);
