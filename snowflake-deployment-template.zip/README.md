# Snowflake Deployment Template

This repo demonstrates how to deploy Snowflake objects using SQL scripts stored in Git.

## 🚀 How to Run

1. Create Git repository in Snowflake
2. Fetch repo
3. Execute:

```sql
EXECUTE IMMEDIATE FROM @your_repo/branches/main/sql/base.sql;
```

## 📁 Structure

- sql/ → All SQL scripts
- config/ → Environment configs
- scripts/ → Deployment helpers
- data/ → Sample data

## 🔁 Workflow

1. Update SQL in GitHub
2. Run:
```sql
ALTER GIT REPOSITORY your_repo FETCH;
```
3. Re-run base.sql

## 🧠 Features

- Modular SQL
- Version controlled
- Idempotent scripts
